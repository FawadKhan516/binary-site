<?php
    $userIp = $_SERVER['REMOTE_ADDR'];
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http";
    $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    // echo $url; // Outputs: Full URL

    ?>
<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">
  <?php include "templates/global-head.php"; ?>
  

</head>

<body>
  <!-- header Section -->

<?php include "templates/header.php"; ?>

  <!-- Hero Section -->
  <section class="hero banner-a" id="hero" style="background-image: url('assets/img/banner.jpg');">
    <div class="container-fluid">
      <div class="hero-content">
        <h1 class="head1 ani-a fade-right-a animated delay-1">Affordable Full House <span> Design and Development </span>Services</h1>
        <h4 class="ani-a fade-up-a animated delay-1">We offer a one-stop shop for bringing your business online, affordably. From creating a killer logo and website to building a sleek mobile app (Android, iOS, or hybrid - we do it all!)</h4>
        <!-- <a href="#services" class="cta-button">Scroll to Explore</a> -->
      </div>
    </div>
    <div class="robotHand ani-a fade-right-a delay-2">
      <img src="assets/img/hand.png" alt="">
    </div>
    <div class="mouse-container ani-a fade-in-a animated delay-2">
      <!-- Optionally wrap this in an 'a' tag to scroll down on click. -->
      <a href="#services" class="cta-button">
        <p class="p">Scroll to explore</p>
        <span class="mouse-outer">
          <span class="mouse-wheel"></span>
        </span>
      </a>
    </div>
  </section>
  <!-- Welcome Section -->
  <section class="welcome">
    <div class="innerwelcome text-center text-white">
      <div class="container">
        <div class="main-hd">
          <h4 class="ani-a fade-down-a delay-1">Welcome to Binary Design Hub</h4>
          <h2 class="ani-a fade-up-a delay-1">Bringing Your Digital Dreams to Life</h2>
          <p class="p ani-a fade-in-a delay-2">Unleash the power of your digital vision with Binary Design Hub, a leading digital agency with over 8 years of experience. Our creative minds and tech wizards blend the perfect balance of artistry and technical expertise to craft captivating websites, user-friendly apps, and data-driven digital marketing strategies.
          </p>
        </div>
        <div class="features">
          <div class="feature ani-a fade-up-a delay-2">
            <img class="mr-3" src="assets/img/rocket.png" alt="Generic placeholder image">
            <div class="media-body">
              <h3>Design</h3>
              <p>Creative design solutions tailored to your business needs.</p>
            </div>
          </div>
          <div class="feature ani-a fade-up-a delay-3">
            <img class="mr-3" src="assets/img/bulb.png" alt="Generic placeholder image">
            <div class="media-body">
              <h3>Design</h3>
              <p>Creative design solutions tailored to your business needs.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Portfolio Section -->
  <section class="portfolio-container">
    <div class="container-fluid">
      <div class="portfolio-content main-hd">
        <h4 class="ani-a fade-down-a animated">Our <span>Creative Portfolio</span></h4>
        <h2 class="ani-a fade-up-a animated">Crafting Exceptional Digital Experiences</h2>
      </div>
      <div class="portfolio-tab">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="mobile-app-tab" data-bs-toggle="tab" data-bs-target="#mobile" type="button" role="tab" aria-controls="mobile" aria-selected="true">Android</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="website-tab" data-bs-toggle="tab" data-bs-target="#website" type="button" role="tab" aria-controls="website" aria-selected="false" tabindex="-1">IOS</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="games-tab" data-bs-toggle="tab" data-bs-target="#games" type="button" role="tab" aria-controls="games" aria-selected="false" tabindex="-1">Games</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="cms-tab" data-bs-toggle="tab" data-bs-target="#cms" type="button" role="tab" aria-controls="cms" aria-selected="false" tabindex="-1">CMS</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="nft-tab" data-bs-toggle="tab" data-bs-target="#nft" type="button" role="tab" aria-controls="nft" aria-selected="false" tabindex="-1">E-Commerce</button>
          </li>
        </ul>
        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="mobile" role="tabpanel" aria-labelledby="mobile-tab">
            <div class="portfolio-slide-Box">
              <div class="portfolio-slider">
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-1.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-2.png" alt="">
                </div>
                <div class="portfolio-slide ">
                  <img src="assets/img/portfolio/app-3.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-4.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-5.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-6.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-7.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-8.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-9.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-10.png" alt="">
                </div>
              </div>
              <div class="iphone-frame">
                <img src="assets/img/iphone-frame.png" alt="iphone-image">
              </div>
              <div class="ellipse-frame">
                <img src="assets/img/ellipse.png" alt="iphone-image">
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="website" role="tabpanel" aria-labelledby="website-tab">
            <div class="portfolio-slide-Box">
              <div class="portfolio-slider">
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-1.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-2.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-3.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-4.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-5.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-6.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-7.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-8.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-9.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-10.png" alt="">
                </div>
              </div>
              <div class="iphone-frame">
                <img src="assets/img/iphone-frame.png" alt="iphone-image">
              </div>
              <div class="ellipse-frame">
                <img src="assets/img/ellipse.png" alt="iphone-image">
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="games" role="tabpanel" aria-labelledby="games-tab">
            <div class="portfolio-slide-Box">
              <div class="portfolio-slider">
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-1.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-2.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-3.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-4.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-5.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-6.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-7.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-8.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-9.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-10.png" alt="">
                </div>
              </div>
              <div class="iphone-frame">
                <img src="assets/img/iphone-frame.png" alt="iphone-image">
              </div>
              <div class="ellipse-frame">
                <img src="assets/img/ellipse.png" alt="iphone-image">
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="cms" role="tabpanel" aria-labelledby="cms-tab">
            <div class="portfolio-slide-Box">
              <div class="portfolio-slider">
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-1.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-2.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-3.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-4.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-5.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-6.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-7.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-8.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-9.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-10.png" alt="">
                </div>
              </div>
              <div class="iphone-frame">
                <img src="assets/img/iphone-frame.png" alt="iphone-image">
              </div>
              <div class="ellipse-frame">
                <img src="assets/img/ellipse.png" alt="iphone-image">
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="nft" role="tabpanel" aria-labelledby="nft-tab">
            <div class="portfolio-slide-Box">
              <div class="portfolio-slider">
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-1.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-2.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-3.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-4.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-5.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-6.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-7.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-8.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-9.png" alt="">
                </div>
                <div class="portfolio-slide">
                  <img src="assets/img/portfolio/app-10.png" alt="">
                </div>
              </div>
              <div class="iphone-frame">
                <img src="assets/img/iphone-frame.png" alt="iphone-image">
              </div>
              <div class="ellipse-frame">
                <img src="assets/img/ellipse.png" alt="iphone-image">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Services Sec -->
  <section class="serv-sec">
    <div class="container-fluid">
      <div class="main-hd text-center">
        <h4 class="ani-a fade-down-a delay-1">Our Services</h4>
        <h2 class="ani-a fade-up-a delay-2">Build Your Brand With The Best Agency</h2>
      </div>
    </div>
    <section class="tekrevol-home-discovery  overflow-x-hidden ani-a fade-in-a delay-2">
      <div class="accordion width" id="accordionHorizontalExample">
        <div class="card">
          <div class="card-header active">Discovery &amp; Analysis<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse show width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="69" height="67" fill="none" viewBox="0 0 69 67">
                    <path fill="#F47A1F" d="M54.755 36.162l3.62 3.619v21.224c0 1.666-.559 3.057-1.675 4.172-1.116 1.116-2.507 1.674-4.173 1.674H6.308c-1.666 0-3.057-.558-4.173-1.674C1.019 64.063.461 62.671.461 61.005V14.798c0-1.666.558-3.056 1.674-4.172C3.251 9.51 4.642 8.952 6.308 8.952h19.42a11.944 11.944 0 00-.424 1.883c-.08.587-.156 1.165-.23 1.736H6.308c-.557 0-1.068.232-1.532.696-.464.463-.695.974-.695 1.531v46.207c0 .557.231 1.068.695 1.532.464.464.975.695 1.532.695h46.219c.557 0 1.068-.231 1.532-.695.464-.464.696-.975.696-1.532V36.162zm1.642-13.653l12 11.996-2.561 2.562-12-11.998a10.454 10.454 0 01-3.759 2.123 14.176 14.176 0 01-4.371.689c-3.782 0-6.978-1.305-9.589-3.915-2.61-2.61-3.915-5.805-3.915-9.586 0-3.78 1.305-6.976 3.915-9.586C38.727 2.184 41.924.88 45.706.88c3.781 0 6.978 1.305 9.588 3.914 2.61 2.61 3.915 5.805 3.915 9.586 0 1.629-.252 3.12-.758 4.475a13.241 13.241 0 01-2.054 3.654zm-10.691 1.753c2.766 0 5.104-.956 7.016-2.867s2.868-4.25 2.868-7.015c0-2.765-.956-5.103-2.868-7.015-1.912-1.91-4.25-2.867-7.016-2.867s-5.105.956-7.017 2.867c-1.912 1.912-2.867 4.25-2.867 7.015 0 2.765.955 5.104 2.867 7.015 1.912 1.911 4.25 2.867 7.017 2.867zM4.08 63.232V12.571v22.547-1.016 29.13z"></path>
                  </svg></div>
                <h3 class="title">Discovery &amp; Analysis</h3>
                <p>Identify business needs and technical requirements through in-depth consultations. Analyze current systems and processes to pinpoint areas for improvement.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">Feasibility &amp; Impact Assessment<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="67" height="67" fill="none" viewBox="0 0 67 67">
                    <g fill="#F47A1F" clip-path="url(#clip0_719_2033)">
                      <path d="M33.483 66.967H2.087c-.774 0-2.012.37-1.97-.952.035-1.187 1.206-.828 1.951-.84 3.486-.045 3.486-.026 3.486-3.552 0-3.166-.016-6.334 0-9.501.014-1.95.25-2.158 2.208-2.172 2.447 0 4.894.035 7.341-.016 1.223-.025 1.702.445 1.691 1.675-.043 3.98.057 7.961-.052 11.944-.043 1.552.688 1.61 1.885 1.628 1.278.027 1.854-.214 1.84-1.69-.073-7.192-.035-14.388-.03-21.576 0-2.172.128-2.294 2.32-2.297h7.069c1.686 0 1.881.196 1.881 1.879 0 7.33 0 14.658.017 21.988 0 .543-.302 1.357.432 1.547.944.236 1.993.334 2.92-.084.452-.204.272-.815.272-1.257V48.218c0-1.935.142-2.068 2.105-2.071h7.34c1.526 0 1.82.271 1.825 1.835.017 5.201.065 10.405-.027 15.603-.027 1.61.816 1.553 1.941 1.585 1.191.036 1.792-.152 1.781-1.588-.062-9.047-.032-18.092-.03-27.145 0-1.976.18-2.155 2.175-2.171 2.266-.011 4.532-.011 6.798 0 1.917 0 2.23.27 2.243 2.193.027 4.614 0 9.23.014 13.844 0 4.433.03 8.866-.02 13.301-.013 1.18.376 1.65 1.57 1.553a27.855 27.855 0 012.854 0c.604 0 1.088.239 1.074.939-.024.616-.481.814-1.033.847-.451.019-.905.016-1.36.016l-31.115.008zM52.121 50.73c0 4.381.017 8.763-.013 13.144 0 .907.247 1.322 1.229 1.29a83.655 83.655 0 015.019 0c.87.021 1.202-.291 1.202-1.179-.022-8.853-.022-17.705 0-26.556 0-.912-.386-1.175-1.23-1.154-1.582.035-3.167.063-4.747 0-1.114-.051-1.498.329-1.482 1.463.055 4.322.022 8.657.022 12.992zm-29.663 2.492c0 3.529.022 7.058-.017 10.587 0 .969.272 1.403 1.314 1.357 1.582-.065 3.17-.046 4.755 0 .876.022 1.218-.326 1.215-1.194a5957.52 5957.52 0 010-21.307c0-.974-.435-1.246-1.33-1.219-1.492.044-2.99.071-4.483 0-1.133-.06-1.498.356-1.479 1.474.057 3.423.022 6.863.025 10.302zm22.159 3.399c0-2.487-.022-4.973 0-7.457 0-.874-.318-1.216-1.196-1.195a98.1 98.1 0 01-4.894 0c-.892-.021-1.197.37-1.191 1.22.016 4.927.016 9.854 0 14.78 0 .868.342 1.213 1.215 1.191 1.585-.04 3.173-.06 4.753 0 1.038.044 1.335-.382 1.316-1.357-.033-2.389-.003-4.785-.003-7.182zM7.531 58.585c0 1.808.022 3.616 0 5.429 0 .795.272 1.154 1.1 1.137 1.765-.035 3.535-.027 5.297 0 .759 0 1.044-.31 1.042-1.056-.02-3.751-.02-7.502 0-11.254 0-.736-.272-1.086-1.03-1.07-1.765.022-3.535.03-5.297 0-.816-.016-1.126.318-1.112 1.127.022 1.9 0 3.787 0 5.687z"></path>
                      <path d="M30.707 27.512c-.253.795.169 1.281.878 1.69 1.686.975 3.35 1.982 5.009 2.987.543.337 1.025.453 1.615.04 1.479-1.03 3.072-1.286 4.744-.474.544.271.922.138 1.332-.25a597.492 597.492 0 016.958-6.472c.566-.515.419-.963.229-1.563-.849-2.688.636-5.334 3.317-5.994 2.59-.638 5.206 1.17 5.666 3.92.41 2.465-1.55 4.886-4.2 5.206a3.54 3.54 0 01-2.116-.336c-.816-.432-1.319-.147-1.903.415a367.714 367.714 0 01-6.428 6.045c-.568.522-.748.967-.478 1.754.652 1.9.084 3.857-1.409 5.01-1.493 1.155-3.184 1.475-4.962.606-1.778-.868-2.768-2.587-2.567-4.669.08-.814-.182-1.257-.85-1.628a155.374 155.374 0 01-5.004-3.008c-.655-.413-1.141-.459-1.821.024a4.255 4.255 0 01-4.503.421c-.625-.293-1.055-.255-1.569.217a401.132 401.132 0 01-6.658 5.997c-.598.526-.514 1.026-.332 1.685.742 2.677-.767 5.234-3.385 5.834a4.63 4.63 0 01-4.896-1.923 4.61 4.61 0 01-.702-1.712c-.354-1.75.25-3.257 1.574-4.376 1.324-1.118 2.928-1.517 4.562-.795.95.418 1.52.271 2.244-.41 1.963-1.876 3.99-3.684 6.03-5.473.66-.575.867-1.099.598-1.99-.582-1.916 0-3.577 1.52-4.866a4.562 4.562 0 015.095-.478c1.648.871 2.545 2.546 2.412 4.566zm25.142-8.125c-1.566 0-2.662 1.056-2.667 2.587a2.646 2.646 0 001.625 2.456 2.656 2.656 0 003.682-2.429c.008-1.534-1.076-2.608-2.64-2.614zM11.26 37.846c-1.57-.016-2.676 1.042-2.687 2.568a2.645 2.645 0 001.608 2.468 2.656 2.656 0 003.7-2.403c.027-1.528-1.053-2.614-2.61-2.628l-.011-.005zm14.902-8.198a2.6 2.6 0 002.453-1.63c.13-.324.192-.67.184-1.02a2.72 2.72 0 00-2.675-2.657c-1.574 0-2.686 1.148-2.656 2.753.038 1.539 1.133 2.576 2.705 2.56l-.011-.006zm14.87 3.635a2.723 2.723 0 00-2.566 1.662c-.14.333-.213.69-.213 1.052a2.607 2.607 0 002.61 2.582 2.527 2.527 0 002.524-1.538c.136-.324.202-.673.195-1.025.055-1.56-1.014-2.703-2.54-2.728l-.01-.005zM11.547 0a11.5 11.5 0 018.11 3.383A11.462 11.462 0 0123 11.499a11.615 11.615 0 01-3.435 8.084 11.652 11.652 0 01-8.118 3.38c-6.368 0-11.46-5.175-11.447-11.64C.01 4.964 5.087-.012 11.547 0zm-1.12 6.99c0-1.176.014-2.35 0-3.529-.022-1.4-.272-1.58-1.631-1.192-4.894 1.404-7.714 6.22-6.662 11.339 1.148 5.59 7.741 8.971 12.975 6.683.922-.402 1.042-.814.424-1.599-.834-1.067-1.506-2.272-2.4-3.282-2.165-2.43-3.375-5.106-2.706-8.42zm6.216 3.415h3.262c.865 0 1.088-.35.868-1.19-.968-3.631-3.293-5.92-6.847-7.022-.987-.306-1.547-.097-1.511 1.108.057 1.938.046 3.879 0 5.817-.02.92.31 1.333 1.253 1.298.984-.038 1.98-.008 2.975-.011zm.51 1.995c-.856 0-1.712.016-2.566 0-.786-.02-1.177.12-.563.947 1.1 1.482 2.178 2.98 3.233 4.493.446.64.816.559 1.267.043a10.098 10.098 0 002.295-4.375c.185-.76-.02-1.119-.816-1.105-.957.013-1.903 0-2.85-.003zM35.698 9.835c-.952 0-1.903.016-2.852 0-.95-.017-1.528-.475-1.526-1.499 0-1.4 0-2.801.014-4.202.016-.92.495-1.406 1.452-1.403h5.981c.887 0 1.36.445 1.36 1.325v4.343c0 .96-.544 1.4-1.441 1.428-.995.032-1.99 0-2.99 0l.002.008zm0-1.957c2.433 0 2.363 0 2.447-1.57.07-1.27-.438-1.718-1.65-1.61-.718.063-1.444 0-2.176.025-.364 0-.707.063-.905.46-.693 1.378.076 2.686 1.596 2.695h.688zM35.77 18.915c-.996 0-1.988-.017-2.991 0-1.004.016-1.441-.448-1.455-1.376a134.635 134.635 0 010-4.325c0-.882.49-1.295 1.378-1.29 1.985.014 3.973.017 5.958 0 .943 0 1.452.397 1.454 1.358v4.324c0 .883-.484 1.311-1.36 1.306-.992-.003-1.992 0-2.985.003zm-.066-1.83c2.507 0 2.657-.168 2.42-2.394-.073-.695-.405-1.037-1.036-.91-1.237.253-2.944-.838-3.657.65-.837 1.753-.038 2.652 1.868 2.654h.405zM48.22 3.55h4.35c.704 0 1.49.052 1.53.95.041.9-.747 1.03-1.449 1.035-3.032.016-6.064.016-9.095 0-.701 0-1.487-.106-1.46-1.02.028-.916.816-.962 1.515-.964 1.53-.006 3.07 0 4.608 0zM48.094 14.582h-4.741c-.631 0-1.243-.119-1.246-.904-.002-.784.604-.912 1.24-.912h9.484c.636 0 1.245.139 1.248.907.003.768-.606.91-1.243.91-1.582.002-3.162 0-4.742 0zM45.204 18.063c-.723 0-1.444.032-2.175 0-.544-.036-.952-.34-.949-.94a.895.895 0 01.848-.904 18.614 18.614 0 014.449-.013c.543.057.932.385.872 1.001-.06.617-.489.842-1.027.87-.677.029-1.36 0-2.029 0l.011-.015zM45.306 7.101c.723 0 1.447-.038 2.175.014a.797.797 0 01.783.917.768.768 0 01-.772.793 96.27 96.27 0 01-4.6 0 .787.787 0 01-.78-.92.838.838 0 01.57-.772.844.844 0 01.335-.043c.767-.027 1.533 0 2.3 0l-.01.011z"></path>
                    </g>
                    <defs>
                      <clipPath id="clip0_719_2033">
                        <path fill="#fff" d="M0 0H67V67H0z"></path>
                      </clipPath>
                    </defs>
                  </svg></div>
                <h3 class="title">Feasibility &amp; Impact Assessment</h3>
                <p>Evaluate technical feasibility and potential impact on business operations. Provide detailed cost and timeline estimates based on comprehensive analysis.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">Solution Architecture Design<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="65" height="65" fill="none" viewBox="0 0 65 65">
                    <path fill="#F47A1F" d="M23.048 30.674l8.284-8.306-7.447-7.468-4.198 4.198-2.567-2.567 4.178-4.198-7.079-7.078-8.304 8.306 17.133 17.113zm28.41 28.43l8.306-8.305-7.079-7.078-4.198 4.177-2.566-2.566 4.177-4.199-7.398-7.377-8.285 8.284 17.043 17.064zm-35.495 1.458H4.527V49.126L20.46 33.19.901 13.561 14.218.24 33.94 19.893l16.2-16.22c.4-.4.82-.688 1.263-.865a3.775 3.775 0 011.415-.265c.502 0 .974.089 1.416.265.441.177.862.466 1.262.865l5.92 6.151c.4.4.676.82.83 1.262.153.442.23.914.23 1.416 0 .502-.077.958-.23 1.37-.154.411-.43.817-.83 1.216l-16.06 16.151 19.49 19.63-13.318 13.32-19.63-19.56-15.935 15.934zm-7.81-3.627h6.262L50.022 21.35l-6.283-6.284L8.153 50.673v6.262zm38.772-38.75l-3.186-3.118 6.283 6.283-3.097-3.166z"></path>
                  </svg></div>
                <h3 class="title">Solution Architecture Design</h3>
                <p>Develop a robust, scalable architecture tailored to your business needs. Ensure seamless integration with existing systems and future scalability.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">Technology Selection &amp; Prototyping<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="73" height="73" fill="none" viewBox="0 0 73 73">
                    <g fill="#F47A1F" clip-path="url(#clip0_720_2054)">
                      <path d="M17.042 21.368c.677-.742 1.137-1.205 1.552-1.705a1.078 1.078 0 000-1.543c-.497-.54-1.12-.585-1.637-.09a100.573 100.573 0 00-3.813 3.815c-.534.569-.392 1.256.128 1.793a148.405 148.405 0 003.412 3.41c.568.568 1.253.764 1.884.136.632-.628.347-1.295-.181-1.872-.381-.415-.774-.816-1.422-1.498h7.625c.63 0 .762.458.762.978v10.797c0 .779-.325 1.109-1.106 1.106H3.493c-.946 0-1.052-.554-1.06-1.299 0-.972.176-2.29-1.223-2.29-1.574 0-1.168 1.42-1.19 2.395a126.583 126.583 0 000 5.4c.045 3.011 2.313 5.316 5.315 5.333 5.731.028 11.462.028 17.194 0a5.247 5.247 0 005.25-5.237c.037-5.209.049-10.417 0-15.628-.014-1.279.407-1.657 1.643-1.56 3.554.284 5.87 2.64 5.89 6.183.026 4.026 0 8.05 0 12.073 0 5.399 3.128 8.73 8.47 9.002 1.136.057 1.162.648 1.16 1.475-.012 4.83-.012 9.66 0 14.491 0 3.819 2.145 5.933 6.003 5.939h9.805c.92 0 2.169.219 2.169-1.151s-1.274-1.267-2.254-1.27c-3.363-.017-6.73 0-10.09-.02-2.032-.017-3.127-1.194-3.215-3.171-.045-1.097.307-1.509 1.447-1.498 4.785.052 9.57.023 14.354.023 2.035 0 4.073.037 6.109 0 1.009-.025 1.316.384 1.305 1.344-.026 2.018-1.035 3.157-3.068 3.328a4.866 4.866 0 00-.853.088c-.6.159-1.04.505-1.012 1.187.032.74.492 1.052 1.197 1.137a5.404 5.404 0 005.664-3.131c.318-.706.48-1.471.477-2.245.028-6.487 0-12.974 0-19.459V32.651c0-3.37-2.246-5.623-5.592-5.631-5.638-.014-11.276-.014-16.912 0-3.27 0-5.532 2.273-5.546 5.535-.017 4.83-.054 9.66.025 14.491.023 1.401-.514 1.705-1.754 1.608-3.112-.204-5.418-2.784-5.455-6.325-.043-4.069 0-8.143-.014-12.218 0-5.026-3.338-8.567-8.335-8.695-1.368-.034-1.652-.52-1.638-1.759.06-4.591.029-9.186.023-13.778 0-3.663-2.172-5.84-5.802-5.856h-1.706c-.753 0-1.356.284-1.421 1.085-.057.884.583 1.245 1.367 1.31.66.054 1.328.017 1.99.04 2.473.085 4.125 2.867 3.036 5.09-.241.49-.67.476-1.088.476H3.552c-.768 0-1.072-.315-1.137-1.094-.247-3.165.955-4.66 4.042-4.512 2.456.12 4.924.029 7.392.02.425.016.85-.013 1.27-.085.603-.13 1.046-.486 1.024-1.17A1.088 1.088 0 0014.958.045c-3.505 0-7.016-.131-10.518.07C1.952.263.008 2.675-.003 5.232c-.029 7.812 0 15.628 0 23.437 0 .87.113 1.719 1.225 1.682 1.111-.037 1.197-.924 1.197-1.762.011-5.257.011-10.512 0-15.767 0-.426.02-.853 0-1.279-.034-.793.346-1.088 1.117-1.088 6.868.011 13.737.011 20.607 0 .853 0 1.191.318 1.186 1.17a492.322 492.322 0 000 8.525c0 .81-.262 1.233-1.137 1.222-2.243-.02-4.512-.003-7.15-.003zm53.513 29.065c0 3.882-.017 7.763 0 11.65 0 .94-.285 1.376-1.297 1.37-6.866-.023-13.732-.023-20.598 0-.993 0-1.33-.39-1.317-1.353.037-2.46 0-4.921 0-7.388 0-3.654 0-3.637 3.676-3.645.91 0 1.623.08 2.061 1.071.478 1.08 1.512 1.623 2.638 1.67 2.178.12 4.36.12 6.539 0 2.134-.144 3.41-1.946 3.272-4.224-.14-2.174-1.558-3.547-3.642-3.547-.807 0-1.629.069-1.706 1.066-.076.997.663 1.299 1.49 1.347 1.015.057 1.461.594 1.421 1.554-.04.96-.64 1.42-1.589 1.42-1.657 0-3.315.038-4.972 0-1.22-.036-1.657-.681-1.48-1.883.124-.852.727-.986 1.406-1.136.68-.151 1.152-.569 1.078-1.288-.086-.795-.668-1.051-1.422-1.077-1.185-.04-2.274.339-2.803 1.344-.645 1.194-1.558 1.35-2.709 1.268a12.114 12.114 0 00-1.845 0c-1.038.085-1.421-.336-1.421-1.39.048-2.793.054-5.586 0-8.376-.023-1.114.364-1.475 1.478-1.47 6.723.04 13.45.052 20.184 0 1.299 0 1.597.47 1.578 1.663-.055 3.782-.017 7.57-.02 11.354zM58.976 34.996H48.742c-.54 0-1.245.15-1.342-.674-.284-2.43.034-4.936 3.588-4.887 5.205.068 10.41.014 15.612.017 3.048 0 3.923.96 3.98 3.998.023 1.301-.483 1.597-1.671 1.574-3.32-.068-6.621-.028-9.933-.028zm-45.033 8.808c-2.788 0-5.58.026-8.369 0-1.941-.023-3.027-1.193-3.127-3.097-.06-1.137.264-1.62 1.495-1.583 2.647.077 5.297.023 7.943.023 4.02 0 8.04.034 12.06-.02 1.156-.017 1.472.426 1.42 1.503-.079 1.99-1.173 3.154-3.197 3.177-2.738.031-5.476.008-8.225.008v-.01z"></path>
                      <path d="M13.908 6.183h3.394c.745 0 1.319-.284 1.347-1.114.029-.83-.534-1.236-1.248-1.25-2.308-.043-4.62-.043-6.925.02-.705.017-1.305.457-1.233 1.267.07.81.662 1.08 1.421 1.08l3.244-.003zM59.01 33.171h3.412c.753 0 1.333-.34 1.373-1.136.04-.796-.543-1.23-1.27-1.245-2.315-.043-4.63-.043-6.948 0-.717 0-1.308.39-1.291 1.216.017.827.568 1.137 1.325 1.16 1.128.014 2.265.005 3.4.005z"></path>
                    </g>
                    <defs>
                      <clipPath id="clip0_720_2054">
                        <path fill="#fff" d="M0 0H73V73H0z" transform="matrix(-1 0 0 1 73 0)"></path>
                      </clipPath>
                    </defs>
                  </svg></div>
                <h3 class="title">Technology Selection &amp; Prototyping</h3>
                <p>Select the most suitable technologies and create prototypes. Validate design choices and gather stakeholder feedback for iterative improvements.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">Agile Development Process<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="67" height="68" fill="none" viewBox="0 0 67 68">
                    <g fill="#F47A1F" clip-path="url(#clip0_720_2067)">
                      <path d="M49.371 8.648A28.082 28.082 0 0038.98 4.625C31.54 3.322 24.567 4.6 18.066 8.46c-.648.384-1.288.756-2.063.471a1.44 1.44 0 01-.94-1.248c-.102-.792.348-1.28.974-1.663a31.922 31.922 0 0110.948-4.316C35.083.211 42.79 1.336 50.035 5.3c.194.104.4.189.734.345 0-1.265-.463-2.303-.714-3.377-.237-1.016-.113-1.884 1.004-2.19 1.116-.307 1.695.358 1.957 1.385.585 2.298 1.216 4.585 1.776 6.888.397 1.624.058 2.174-1.539 2.596-2.26.6-4.535 1.147-6.802 1.73-.948.244-1.814.17-2.15-.867-.337-1.038.295-1.78 1.249-2.112 1.116-.386 2.283-.635 3.821-1.049zM18.077 59.979a28.578 28.578 0 0010.3 3.872c7.398 1.253 14.318-.038 20.763-3.872.648-.386 1.29-.753 2.062-.452a1.438 1.438 0 01.924 1.262c.09.795-.375 1.266-.993 1.644a31.745 31.745 0 01-10.665 4.274c-7.841 1.594-15.333.565-22.41-3.162-1.103-.587-1.357-.313-1.23.821.069.633.025 1.276.066 1.917.058.978-.345 1.643-1.343 1.717-.998.074-1.601-.463-1.704-1.416-.19-1.81-.308-3.628-.444-5.447-.055-.725-.052-1.457-.107-2.19-.088-1.14.356-1.918 1.547-2 2.65-.21 5.303-.384 7.957-.523.899-.046 1.323.592 1.44 1.37.126.843-.318 1.385-1.142 1.613-1.257.347-2.562.123-3.833.323-.303.049-.595.115-1.188.249zM59.613 48.943a25.635 25.635 0 003.94-12.247c.403-6.405-.907-12.416-4.331-17.92-.552-.915-.69-1.866.413-2.465 1.103-.6 1.812.046 2.333.969 6.137 10.894 6.531 21.908.672 33.032-.73 1.388-.769 1.37.808 1.6.726.106 1.467.136 2.178.298.828.189 1.476.654 1.363 1.607-.105.885-.731 1.476-1.591 1.405-2.741-.232-5.473-.536-8.197-.912-.806-.11-1.197-.797-1.103-1.643.256-2.536.493-5.074.783-7.608.127-1.095.755-1.848 1.93-1.626 1.174.222 1.27 1.139 1.144 2.144-.146 1.123-.232 2.237-.342 3.366zM7.566 19.534A22.453 22.453 0 003.943 28.6c-1.343 7.55-.24 14.695 3.78 21.311.57.945.915 1.854-.215 2.618-.888.603-1.793.238-2.529-1.079-5.983-10.705-6.363-21.566-.849-32.566.767-1.528.75-1.558-1.009-1.704a9.11 9.11 0 01-2.027-.34c-.766-.243-1.235-.82-1.053-1.678.171-.808.703-1.325 1.558-1.249 2.647.245 5.29.519 7.93.822 1.194.14 1.604.94 1.48 2.056-.259 2.263-.51 4.525-.8 6.781-.126.98-.55 1.87-1.712 1.74-1.16-.132-1.378-1.014-1.249-2.058.144-1.232.213-2.478.318-3.721z"></path>
                    </g>
                    <defs>
                      <clipPath id="clip0_720_2067">
                        <path fill="#fff" d="M0 0H67V68H0z"></path>
                      </clipPath>
                    </defs>
                  </svg></div>
                <h3 class="title">Agile Development Process</h3>
                <p>Implement solutions using Agile methodologies. Ensure continuous integration, testing, and delivery for high-quality, reliable outputs.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">System Integration &amp; Testing<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="68" height="68" fill="none" viewBox="0 0 68 68">
                    <path fill="#F47A1F" d="M33.563 67.389H8.242c-4.968 0-8.222-3.312-8.23-8.223v-2.36c-.084-1.35.273-2.4 1.655-2.989.828-.348.53-1.126.53-1.739V21.242 14.03c0-3.585 2.054-5.945 5.606-6.177 3.312-.207 6.624-.116 9.936-.116a2.012 2.012 0 002.004-1.076 11.75 11.75 0 012.435-2.534 2.244 2.244 0 012.707-.083c.68.398 1.309.828 1.98 1.284a1.656 1.656 0 002.69-1.102c.191-.761.29-1.548.506-2.301A2.344 2.344 0 0132.545.012h.265c4.09-.058 4.09-.058 4.968 3.974.364 1.656 1.49 2.112 2.882 1.259.078-.041.152-.088.223-.14 3.37-2.485 4.14-1.707 6.873 1.655a2.078 2.078 0 001.797 1.01c3.37 0 6.74-.09 10.102.125 3.544.223 5.572 2.591 5.589 6.177v38.18c0 .828.107 1.482 1.01 1.88a2.053 2.053 0 011.143 2.062v3.544a7.784 7.784 0 01-7.743 7.65c-8.686.05-17.388 0-26.09 0zm.083-13.746H60.97c1.789 0 1.789 0 1.789-1.838v-36.98c.037-.699-.03-1.4-.2-2.078a2.94 2.94 0 00-2.84-2.31c-3.974-.05-7.957 0-11.94 0a1.764 1.764 0 00-.356 3.477c.646.125 1.292.24 1.93.39 1.805.422 2.393 1.134 2.484 3.005v1.582c-.075 1.788-.68 2.484-2.41 2.915-.637.149-1.283.273-1.912.422a1.656 1.656 0 00-1.102 2.666c.44.704.903 1.4 1.333 2.112a2.243 2.243 0 01.05 2.368c-1.706 3.155-3.75 3.693-6.674 1.755-.182-.124-.356-.257-.546-.364a1.706 1.706 0 00-2.708 1.126c-.166.679-.273 1.375-.422 2.062a2.368 2.368 0 01-2.286 2.161c-1.714 0-3.676.687-4.852-1.308a3.958 3.958 0 01-.348-1.126c-.149-.638-.232-1.292-.405-1.921a1.655 1.655 0 00-2.567-1.044c-.713.414-1.392.903-2.095 1.342a2.335 2.335 0 01-2.377.149c-3.08-1.49-3.767-3.867-1.904-6.625.14-.223.29-.439.43-.654a1.657 1.657 0 00-1.002-2.633c-.828-.215-1.656-.34-2.426-.546a2.41 2.41 0 01-1.838-1.657c-1.01-3.312.1-5.216 3.378-5.92.213-.05.429-.09.646-.116a1.657 1.657 0 001.565-1.913 1.657 1.657 0 00-1.838-1.656H7.936a3.022 3.022 0 00-3.172 2.725 8.827 8.827 0 00-.107 1.656v37.021c0 1.813 0 1.822 1.805 1.822l27.184-.067zm0 11.229h25.719a5.332 5.332 0 005.332-4.033 14.08 14.08 0 00.141-3.784c0-.654-.497-.745-1.018-.745H47.15c-.687 0-.985.265-1.051.993-.29 2.965-2.046 4.555-5.026 4.563H26.376c-3.08 0-4.761-1.516-5.11-4.612-.074-.663-.33-.936-.968-.936H3.514c-.464 0-.886.083-.96.662-.53 4.257.968 7.958 6.044 7.925h25.065l-.017-.033zm11.75-56.903c-.157-.232-.265-.422-.39-.588-.952-1.25-1.126-1.25-2.89-.083-3.013 2.004-6.06.828-6.822-2.732-.083-.381-.15-.77-.224-1.151a1.034 1.034 0 00-1.076-.92c-1.143-.107-1.714.307-1.814 1.466a4.215 4.215 0 01-3.072 4.074c-1.88.663-3.121-.157-4.43-1.126-.737-.546-1.283-.67-2.004.1a1.277 1.277 0 00-.165 1.904c.753 1.093 1.871 2.112 1.457 3.643-.571 2.079-1.482 3.867-4.057 3.909-.301.048-.6.112-.894.19-.588.091-.762.456-.828 1.002-.091 1.085.207 1.656 1.424 1.872 1.217.215 2.6.198 3.312 1.506 1.06 1.897 1.656 3.793-.108 5.64a6.965 6.965 0 00-.588.827.83.83 0 00.116 1.168c.72.886 1.391 1.143 2.418.364 1.027-.778 1.814-1.598 3.13-1.432a4.371 4.371 0 014.14 3.842c.067.34.141.687.19 1.035.108.828.605 1.093 1.45 1.11.844.016 1.291-.332 1.407-1.16.075-.472.232-.935.274-1.416.14-1.424 1.002-2.103 2.227-2.782 1.996-1.11 3.495-.422 5.035.77.588.464 1.142.886 1.92.116.779-.77.878-1.25.249-2.103-.944-1.292-1.888-2.484-1.192-4.405a4.314 4.314 0 014.14-3.155c1.167-.075 1.407-.712 1.4-1.747-.01-1.035-.829-1.093-1.508-1.259-1.209-.281-2.567-.24-3.312-1.548-1.076-1.921-1.548-3.8.182-5.647.345-.387.653-.806.92-1.25l-.017-.034zM33.704 56.293h-8.52c-.456 0-1.036-.166-1.292.381a1.655 1.655 0 00.232 1.615 2.228 2.228 0 002.003 1.026h15.079a2.311 2.311 0 001.863-.828 1.731 1.731 0 00.422-1.821c-.256-.621-.902-.406-1.4-.414a351.61 351.61 0 01-8.37.074l-.017-.033z"></path>
                    <path fill="#F47A1F" d="M40.238 41.513a10.268 10.268 0 1110.31 10.309 10.4 10.4 0 01-10.31-10.31zm17.886 0a7.62 7.62 0 00-14.666-2.868 7.62 7.62 0 009.986 9.921 7.617 7.617 0 004.68-7.053zM16.902 31.311A10.258 10.258 0 116.635 41.63 10.4 10.4 0 0116.902 31.31zm7.618 10.202a7.625 7.625 0 10-15.244.09 7.626 7.626 0 1015.244-.09zM15.289 60.847a16.97 16.97 0 01-1.954-.182 1.208 1.208 0 01.066-2.376c1.168-.19 2.36-.19 3.527 0a1.165 1.165 0 011.079.74c.056.143.084.297.08.452a1.227 1.227 0 01-1.225 1.283c-.524.034-1.05.034-1.573 0v.083zM42.78 17.897a9.108 9.108 0 11-18.19-.966 9.108 9.108 0 0118.19.966zm-2.567.19a6.517 6.517 0 10-13.022-.559 6.517 6.517 0 0013.022.56z"></path>
                    <path fill="#F47A1F" d="M53.71 46.117c-.829-.1-1.234-.828-1.789-1.35-1.424-1.391-1.416-1.4-2.799 0-.358.385-.74.747-1.142 1.085a1.217 1.217 0 01-1.714-1.714 16.751 16.751 0 011.722-1.789c.613-.546.563-.977 0-1.507a19.74 19.74 0 01-1.656-1.656 1.201 1.201 0 010-1.772 1.216 1.216 0 011.772.058c.534.449 1.03.942 1.482 1.474.679.828 1.234.745 1.871 0 .428-.498.893-.963 1.391-1.391a1.226 1.226 0 011.864-.066 1.217 1.217 0 01-.059 1.772 14.81 14.81 0 01-1.473 1.498c-.73.613-.828 1.126 0 1.78.598.52 1.151 1.087 1.656 1.698a1.143 1.143 0 01.099 1.358 1.225 1.225 0 01-1.226.522zM14.678 46.125a1.433 1.433 0 01-1.044-.472c-.654-.646-1.316-1.283-1.938-1.946a1.21 1.21 0 01-.082-1.863 1.134 1.134 0 011.755.066c1.076 1.4 1.813.828 2.733-.19 1.291-1.424 2.7-2.733 4.065-4.09.621-.613 1.333-.986 2.054-.257.72.728.323 1.44-.29 2.053l-6.12 6.12a1.656 1.656 0 01-1.133.579z"></path>
                  </svg></div>
                <h3 class="title">System Integration &amp; Testing</h3>
                <p>Integrate new solutions with existing infrastructure. Conduct thorough testing to ensure functionality, performance, and security.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">Deployment &amp; User Training<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="62" height="63" fill="none" viewBox="0 0 62 63">
                    <path fill="#F47A1F" d="M6.82 27.686l8.886 3.76a76.298 76.298 0 013.677-6.535 65.31 65.31 0 014.386-6.146l-5.565-1.067a1.9 1.9 0 00-1.082.035 2.396 2.396 0 00-.941.593l-9.361 9.36zm11.76 6.062l10.267 10.247c2.865-1.294 5.748-2.938 8.65-4.932 2.902-1.995 5.691-4.332 8.37-7.01 3.906-3.906 6.89-8.072 8.952-12.496 2.063-4.424 3.222-9.534 3.477-15.328-5.794.256-10.895 1.415-15.303 3.477-4.408 2.062-8.565 5.047-12.472 8.953-2.678 2.678-5.014 5.48-7.01 8.405-1.994 2.924-3.638 5.82-4.931 8.684zm18.791-8.614c-1.065-1.066-1.597-2.343-1.597-3.833 0-1.49.532-2.768 1.597-3.833 1.065-1.065 2.358-1.598 3.878-1.598s2.813.533 3.878 1.598c1.066 1.065 1.598 2.343 1.598 3.833 0 1.49-.532 2.768-1.598 3.833-1.065 1.064-2.357 1.596-3.878 1.596-1.52 0-2.813-.532-3.878-1.596zm-2.532 30.641l9.36-9.36c.28-.279.477-.593.594-.942a1.9 1.9 0 00.034-1.081l-1.067-5.566a64.04 64.04 0 01-6.145 4.377 78.224 78.224 0 01-6.535 3.665l3.76 8.907zM61.687.887c.404 6.664-.539 12.794-2.83 18.39C56.568 24.875 53 30.096 48.155 34.94a578.056 578.056 0 01-1.255 1.256l1.465 7.443a5.848 5.848 0 01-.112 2.838 5.665 5.665 0 01-1.464 2.435l-13.211 13.14-6.013-14.166L14.64 34.961.473 28.88l13.12-13.142a5.976 5.976 0 012.444-1.5 5.631 5.631 0 012.85-.146l7.582 1.534c.233-.232.43-.441.593-.627.162-.187.36-.396.593-.628C32.5 9.525 37.717 5.966 43.307 3.692 48.896 1.418 55.023.483 61.687.887zM6.562 45.64c1.418-1.418 3.142-2.119 5.172-2.102 2.03.016 3.754.733 5.172 2.151 1.418 1.418 2.124 3.142 2.117 5.172-.007 2.03-.72 3.755-2.138 5.173-1.232 1.232-3.21 2.287-5.932 3.166-2.723.88-5.872 1.486-9.448 1.82.334-3.575.953-6.725 1.855-9.447.902-2.723 1.97-4.7 3.202-5.933zm2.588 2.637c-.698.698-1.35 1.836-1.954 3.414a20.114 20.114 0 00-1.2 4.887 19.436 19.436 0 004.887-1.224c1.579-.621 2.717-1.28 3.414-1.978.726-.725 1.095-1.59 1.11-2.595.013-1.004-.343-1.87-1.068-2.594-.725-.726-1.59-1.073-2.594-1.043-1.005.03-1.87.408-2.595 1.133z"></path>
                  </svg></div>
                <h3 class="title">Deployment &amp; User Training</h3>
                <p>Deploy the solution across the organization. Provide comprehensive training to ensure smooth adoption and maximize user efficiency.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header ">Continuous Support &amp; Optimization<div class="svg-arrow-icon d-block d-lg-none"><svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.3408 27.4683C20.5911 27.7186 20.9094 27.8359 21.2266 27.8359C21.5437 27.8359 21.862 27.7186 22.1123 27.4683L31.0415 18.5391C31.5267 18.0539 31.5267 17.2528 31.0415 16.7676L22.1123 7.8384C21.6271 7.35322 20.826 7.35322 20.3408 7.8384C19.8557 8.32358 19.8557 9.12466 20.3408 9.60984L28.3844 17.6534L20.3408 25.6969C19.8557 26.1821 19.8557 26.9831 20.3408 27.4683Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
                <path d="M5.14821 18.9049H29.9059C30.5919 18.9049 31.1592 18.3376 31.1592 17.6516C31.1592 16.9657 30.5919 16.3983 29.9059 16.3983H5.14821C4.46223 16.3983 3.89492 16.9657 3.89492 17.6516C3.89492 18.3376 4.46223 18.9049 5.14821 18.9049Z" fill="#494949" stroke="#494949" stroke-width="0.3"></path>
              </svg></div>
          </div>
          <div class="collapse width">
            <div class="card-body">
              <div class="discovery-bg"><svg xmlns="http://www.w3.org/2000/svg" width="684" height="685" fill="none" viewBox="0 0 684 685">
                  <circle cx="341.624" cy="342.455" r="341.624" fill="url(#paint0_radial_1441_6281)"></circle>
                  <defs>
                    <radialGradient id="paint0_radial_1441_6281" cx="0" cy="0" r="1" gradientTransform="rotate(90 -.416 342.04) scale(341.624)" gradientUnits="userSpaceOnUse">
                      <stop stop-color="#314252"></stop>
                      <stop offset="1" stop-color="#001B28"></stop>
                    </radialGradient>
                  </defs>
                </svg></div>
              <div class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="36" fill="none" viewBox="0 0 20 36">
                  <path stroke="#F47A1F" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M1.893 2.377l15.62 15.62-15.62 15.62"></path>
                </svg></div>
              <div class="main-title">Guided Roadmap to <span>Digital Success</span></div>
              <div class="content-wrap">
                <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="66" height="76" fill="none" viewBox="0 0 66 76">
                    <path fill="#F47A1F" d="M32.905 70.986c-2.117-.122-4.535-1.091-7.038-1.712s-4.799-1.252-7.189-1.882c-.668-.179-1.299-.282-1.778.31-.48.593.075 1.017.273 1.497a2.822 2.822 0 01-1.186 3.848 28.112 28.112 0 01-2.983 1.675 2.823 2.823 0 01-3.877-1.11A1140.514 1140.514 0 01.414 58.17a2.823 2.823 0 011.007-3.764C2.24 53.852 3.134 53.4 4 52.92c1.882-1.044 3.218-.809 4.498.941.508.706.875.574 1.458.226 2.136-1.26 4.32-2.456 6.437-3.764a9.692 9.692 0 019.503-.818 42.845 42.845 0 008.384 2.587 4.253 4.253 0 013.566 4.32c0 1.11.358 1.157 1.195.667a1345.5 1345.5 0 0110.05-5.843 10.2 10.2 0 015.353-1.618 4.271 4.271 0 014.225 3.142 4.422 4.422 0 01-1.75 5.129 2091.988 2091.988 0 01-19.666 12.11 7.942 7.942 0 01-4.347.987zm.837-2.775a5.965 5.965 0 003.284-1.214l8.469-5.232 9.513-5.871a1.882 1.882 0 001.007-2.259c-.301-1.044-1.148-1.251-2.127-1.223a8.045 8.045 0 00-3.764 1.327c-3.312 1.882-6.586 3.839-9.917 5.787a8.968 8.968 0 01-5.975 1.326c-2.672-.376-5.213-1.26-7.81-1.881-.941-.236-2.014-.556-1.694-1.816.32-1.261 1.487-1.026 2.475-.772 1.882.48 3.764.997 5.646 1.468 1.044.263 1.966 0 2.248-1.11.283-1.11-.508-1.741-1.524-1.967a75.916 75.916 0 01-9.805-3.077 5.54 5.54 0 00-4.704.31c-2.663 1.459-5.26 3.012-7.904 4.498a.828.828 0 00-.367 1.327 311.27 311.27 0 013.764 6.747c.376.658.809.856 1.42.367a3.16 3.16 0 013.106-.302c2.766.79 5.542 1.553 8.336 2.25 2.048.689 4.17 1.13 6.323 1.317zM14.66 70.347a4.848 4.848 0 00-.254-.603C11.734 65.04 9.065 60.334 6.4 55.63a.753.753 0 00-1.224-.3c-.508.31-1.035.601-1.552.94a.94.94 0 00-.377 1.468c2.607 4.582 5.185 9.165 7.782 13.747.235.414.49.998 1.12.612.856-.574 1.957-.781 2.512-1.75z"></path>
                    <path fill="#F47A1F" d="M41.015 50.107h-.593c-3.641 0-3.378.395-4.601-3.04a1.929 1.929 0 00-1.43-1.364 4.055 4.055 0 01-1.12-.395 4.818 4.818 0 00-5.646-.066 1.533 1.533 0 01-2.032-.367c-1.336-1.327-2.663-2.672-4.009-3.999a1.882 1.882 0 01-.178-2.597c1.947-2.823-.358-4.855-1.186-7.123-.273-.762-1.524-.828-2.362-1.12a2.155 2.155 0 01-1.628-2.352c0-1.486.076-2.983 0-4.47-.075-1.486.49-2.455 1.882-2.737 3.247-.64 3.002-3.764 4.075-5.853.272-.527-.499-1.637-.894-2.437a2.107 2.107 0 01.451-2.7 135.013 135.013 0 003.482-3.482 1.976 1.976 0 012.823-.442c2.757 1.929 4.864-.301 7.151-1.11.771-.274.837-1.412 1.091-2.203A2.38 2.38 0 0138.954.37c1.487.075 2.983.065 4.48 0 1.279-.047 2.201.451 2.417 1.703.574 3.33 3.689 3.199 5.844 4.31.668.347 1.571-.452 2.314-.829a2.249 2.249 0 013.059.508 56.399 56.399 0 003.265 3.275c.94.865 1.27 1.825.517 2.898-1.929 2.757.405 4.855 1.12 7.17.207.668 1.345.78 2.098.997a2.316 2.316 0 011.882 2.757 29.348 29.348 0 000 4.169c.103 1.477-.405 2.437-1.882 2.747-3.19.668-3.04 3.698-4.036 5.853-.34.724.517 1.656.884 2.456a2.032 2.032 0 01-.47 2.663 71.783 71.783 0 00-3.595 3.585 1.76 1.76 0 01-2.512.423c-2.823-1.995-4.96.254-7.32 1.007-.64.207-.744 1.157-.942 1.806a2.615 2.615 0 01-3.284 2.202 14.112 14.112 0 00-1.778.038zM58.13 11.528c0-.743-2.607-3.321-3.237-3.274a.499.499 0 00-.292.075c-2.267 1.675-4.347.79-6.436-.414a4.78 4.78 0 00-1.543-.536 2.917 2.917 0 01-2.606-2.494c-.377-1.882-1.732-1.637-3.087-1.703-1.355-.066-2.437.17-2.757 1.731a2.926 2.926 0 01-2.493 2.428 9.409 9.409 0 00-3.284 1.364 3.134 3.134 0 01-3.764.066 1.788 1.788 0 00-2.823.48 3.765 3.765 0 01-.847.838 1.731 1.731 0 00-.46 2.672 3.293 3.293 0 010 3.877c-.6.975-1.04 2.039-1.308 3.152a3.19 3.19 0 01-2.532 2.597 1.883 1.883 0 00-1.656 2.343c.052.595.052 1.193 0 1.787a1.167 1.167 0 00.941 1.346c2.202.452 3.2 1.938 3.585 3.999.07.395.225.77.452 1.1a4.705 4.705 0 01.273 5.647c-.79 1.289.809 1.674 1.326 2.465.866 1.327 1.967 1.477 3.275.63a2.945 2.945 0 013.35.066 14.577 14.577 0 003.425 1.43 3.067 3.067 0 012.531 2.4 1.992 1.992 0 002.456 1.74c1.383-.122 2.973.377 3.397-1.693a3.03 3.03 0 012.634-2.465 9.164 9.164 0 003.011-1.233 3.209 3.209 0 013.868-.141 1.882 1.882 0 002.907-.593c.208-.282.455-.532.734-.743a1.676 1.676 0 00.518-2.55 3.406 3.406 0 01.094-4.131 9.954 9.954 0 001.27-3.162 2.766 2.766 0 012.192-2.333 2.2 2.2 0 001.882-2.823 8.835 8.835 0 010-1.496 1.195 1.195 0 00-.94-1.327c-2.09-.414-3.068-1.769-3.454-3.764a4.77 4.77 0 00-.753-1.769 3.953 3.953 0 01-.122-4.836c.109-.232.19-.475.245-.725l.028-.028z"></path>
                    <path fill="#F47A1F" d="M39.01 33.989a3.556 3.556 0 01-2.944-1.205c-1.722-1.722-3.463-3.415-5.157-5.166a3.764 3.764 0 01-.17-5.457c1.553-1.6 3.765-1.553 5.562.113l.216.207c2.39 2.343 2.39 2.343 4.705 0 1.505-1.515 2.992-3.049 4.516-4.545 1.882-1.797 4.084-1.882 5.693-.282a3.934 3.934 0 01-.226 5.645c-3.114 3.2-6.285 6.352-9.41 9.532a3.445 3.445 0 01-2.784 1.157zm0-2.654c.437-.11.829-.353 1.12-.696 1.544-1.553 3.087-3.096 4.62-4.648a541.168 541.168 0 004.574-4.705c.451-.47.724-.998.178-1.572a1.081 1.081 0 00-1.6 0c-.422.35-.822.727-1.194 1.13-2.09 2.117-4.16 4.262-6.267 6.37-1.176 1.185-1.816 1.157-3.03 0-.94-.941-1.825-1.826-2.748-2.729-.573-.565-1.27-1.007-1.881-.282-.612.724-.16 1.289.367 1.816l4.704 4.704a1.663 1.663 0 001.148.612h.01z"></path>
                    <path fill="#F47A1F" d="M41.825 41.422c-7.819 0-14.387-4.959-16.193-11.715-.217-.819-.33-1.58.517-2.108.847-.526 1.685 0 2.108 1.355a13.352 13.352 0 0024.182 3.407c.443-.715.998-1.393-.103-2.108a1.11 1.11 0 01-.179-1.496c.555-1.082 3.472-1.619 4.385-.8.4.372.777.768 1.129 1.186a1.534 1.534 0 01.499 1.74 1.289 1.289 0 01-1.6.744c-.94-.188-.94.611-1.167 1.072-3.114 5.58-7.922 8.403-13.578 8.723zM41.165 9.195A16.204 16.204 0 0156.417 20.4c.137.423.231.858.283 1.299a1.28 1.28 0 01-2.456.677c-.216-.442-.32-.94-.499-1.402-2.004-5.354-5.909-8.468-11.536-8.986-5.25-.47-9.41 1.722-12.41 6.173-.5.743-1.092 1.468.093 2.202a1.025 1.025 0 01.236 1.355c-.452.94-3.265 1.834-4.112 1.166a8.31 8.31 0 01-1.826-1.938 1.234 1.234 0 011.054-1.995c1.044.113 1.242-.48 1.6-1.12a16.062 16.062 0 0114.32-8.637z"></path>
                  </svg></div>
                <h3 class="title">Continuous Support &amp; Optimization</h3>
                <p>Offer ongoing support and optimization services. Monitor performance, gather feedback, and implement enhancements to drive sustained growth and innovation</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  </section>
 <!-- Pricing Section -->
<?php include "templates/home-pricing.php"?>
<?php include "templates/counter-section.php"; ?>
<?php include "templates/contactForm.php"; ?>
<?php include "templates/testi-sec.php"; ?>
<?php include "templates/footer.php"?>

<!-- Scripts Section -->
<?php include "templates/global-scripts.php"?>
</body>

</html>

<style>
    /* ========  Services Sec=========== */



section.serv-sec .main-hd {
  padding-bottom: 60px;
}


.tekrevol-home-discovery {
  --easing: cubic-bezier(.8,0,.2,1);
  --duration: 0.4s
}

.tekrevol-home-discovery .accordion {
  counter-reset: section;
  text-align: center
}

.tekrevol-home-discovery .accordion.width {
  display: flex;
  width: 100vw
}

.tekrevol-home-discovery .accordion.width .card {
  background-color: #062738;
  border: 0 solid #062738;
  border-radius: unset;
  counter-increment: section;
  flex-direction: row;
  min-width: min-content;
  overflow: hidden;
  position: relative
}

.tekrevol-home-discovery .accordion.width .card .card-header {
  align-items: center;
  background-color: transparent !important;!i;!;
  border: 1px solid #fff;
  border-bottom: none;
  border-radius: unset;
  border-top: none;
  color: #fff;
  cursor: pointer;
  display: flex;
  font-family: var(--heading-font);
  font-size: 22px;
  font-weight: 600;
  justify-content: flex-start;
  letter-spacing: 5px;
  line-height: 1.5;
  min-height: 1050px;
  position: relative;
  text-transform: uppercase;
  transform: rotate(180deg);
  transition: transform var(
  --duration) var(--easing);
  transition: background-color var(
  --duration) var(--easing),width var(--duration) var(--easing);
  width: 120px;
  writing-mode: vertical-rl;
}

.tekrevol-home-discovery .accordion.width .card .card-header:before {
  bottom: 50px;
  content: "0" counter(section);
  font-family: Poppins,sans-serif;
  font-size: 42px;
  font-weight: 700;
  left: 50%;
  line-height: 38px;
  position: absolute;
  text-align: left;
  transform: translateX(-50%) rotate(90deg)
}

.tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon {
  position: absolute;
  top: 40px;
  transition: all .3s linear
}

.tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon svg {
  transition: all .3s linear
}

.tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon svg path {
  fill: #fff
}

.tekrevol-home-discovery .accordion.width .card .card-header.active .svg-arrow-icon {
  transform: rotate(180deg);
  transition: all .3s linear
}

.tekrevol-home-discovery .accordion.width .card:nth-child(odd) .card-header {
  background-color: transparent !important;!i;!;
}

.tekrevol-home-discovery .accordion.width .card:last-child .card-body .arrow svg {
  transform: rotate(180deg)
}

.tekrevol-home-discovery .card-body {
  animation: slide-in var(--duration) var(--easing) backwards;
  background-color: #001b28;
  color: #fff;
  height: 100%;
  padding: 230px 80px 80px;
  position: relative;
  text-align: left;
  transition: background-color var(--duration) var(--easing),width var(--duration) var(--easing);
  width: 100vw;
  width: calc(100vw - 960px)
}

.tekrevol-home-discovery .card-body .arrow {
  position: absolute;
  right: 50px;
  top: 65%
}

.tekrevol-home-discovery .card-body .discovery-bg {
  bottom: 55px;
  left: 55px;
  position: absolute;
  z-index: 0
}

@keyframes slide-in {
  0% {
      transform: translateX(-100%)
  }

  to {
      transform: translateX(0)
  }
}

.tekrevol-home-discovery .card-body .main-title {
  color: #fff;
  font-size: 54px;
  font-weight: 700;
  letter-spacing: -.03em;
  line-height: 1;
  margin-bottom: 150px;
  max-width: 700px;
  position: relative;
  z-index: 1
}
.tekrevol-home-discovery .card-body .content-wrap .icon path {
    fill: #fff;
}

.tekrevol-home-discovery .card-body .main-title span {
  color: #d400ff;
}

.tekrevol-home-discovery .card-body .content-wrap {
  max-width: 555px;
  position: relative;
  z-index: 1
}

.tekrevol-home-discovery .card-body .content-wrap .icon {
  margin-bottom: 50px
}

.tekrevol-home-discovery .card-body .content-wrap .title {
  color: #fff;
  font-size: 36px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 30px
}

.tekrevol-home-discovery .card-body .content-wrap p {
  margin-bottom: 0
}

.tekrevol-home-discovery .collapse {
  display: block!important;
  max-height: 100%;
  overflow: hidden;
  transition: width var(--duration) var(--easing),max-height var(--duration) var(--easing);
  width: calc(100vw - 960px)
}

.tekrevol-home-discovery .collapse.show {
  width: calc(100vw - 960px)
}

.tekrevol-home-discovery .collapse:not(.show) {
  width: 0
}

.tekrevol-home-discovery .collapse.collapsing {
  animation: collapse-width var(--duration) var(--easing) forwards
}

@keyframes collapse-width {
  0% {
      width: calc(100vw - 960px)
  }

  to {
      width: 0
  }
}

@media screen and (max-width: 1800px) {
  .tekrevol-home-discovery .accordion.width .card .card-header:before {
      font-size:38px
  }

  .tekrevol-home-discovery .card-body {
      padding: 230px 50px 50px
  }

  .tekrevol-home-discovery .card-body .arrow {
      position: absolute;
      right: 15px;
      top: 54%
  }

  .tekrevol-home-discovery .card-body .main-title {
      font-size: 44px
  }

  .tekrevol-home-discovery .card-body .content-wrap .icon {
      margin-bottom: 30px
  }

  .tekrevol-home-discovery .card-body .content-wrap .title {
      font-size: 30px;
      margin-bottom: 20px
  }
}

@media screen and (max-width: 1599px) {
  .tekrevol-home-discovery .accordion.width .card .card-header {
      font-size:16px;
      letter-spacing: 3px;
      min-height: 660px;
      width: 100px;
      background-color: transparent !important;!i;!;
  }

  .tekrevol-home-discovery .accordion.width .card .card-header:before {
      bottom: 30px;
      font-size: 34px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon {
      top: 30px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon svg {
      height: 30px;
      width: auto
  }

  .tekrevol-home-discovery .card-body {
      padding: 180px 30px 30px;
      width: calc(100vw - 815px)
  }

  .tekrevol-home-discovery .card-body .arrow {
      position: absolute;
      right: 25px;
      top: 60%
  }

  .tekrevol-home-discovery .card-body .main-title {
      font-size: 38px;
      margin-bottom: 70px;
      max-width: 460px
  }

  .tekrevol-home-discovery .card-body .content-wrap {
      max-width: 460px
  }

  .tekrevol-home-discovery .card-body .content-wrap .title {
      font-size: 26px
  }

  .tekrevol-home-discovery .collapse,.tekrevol-home-discovery .collapse.show {
      width: calc(100vw - 815px)
  }

  @keyframes collapse-width {
      0% {
          width: calc(100vw - 815px)
      }

      to {
          width: 0
      }
  }
}

@media screen and (max-width: 1399px) {
  .tekrevol-home-discovery .accordion.width .card .card-header {
      font-size:13px;
      letter-spacing: 2px;
      min-height: 530px;
      width: 65px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header:before {
      bottom: 15px;
      font-size: 20px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon {
      top: 20px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon svg {
      height: 25px;
      width: auto
  }

  .tekrevol-home-discovery .card-body {
      padding: 150px 30px 30px;
      width: calc(100vw - 540px)
  }

  .tekrevol-home-discovery .card-body .arrow {
      position: absolute;
      right: 25px;
      top: 60%
  }

  .tekrevol-home-discovery .card-body .discovery-bg svg {
      height: 470px;
      width: auto
  }

  .tekrevol-home-discovery .card-body .main-title {
      font-size: 32px;
      margin-bottom: 60px;
      max-width: 340px
  }

  .tekrevol-home-discovery .card-body .content-wrap {
      max-width: 460px
  }

  .tekrevol-home-discovery .card-body .content-wrap .icon svg {
      height: 50px;
      width: auto
  }

  .tekrevol-home-discovery .card-body .content-wrap .title {
      font-size: 22px
  }

  .tekrevol-home-discovery .collapse,.tekrevol-home-discovery .collapse.show {
      width: calc(100vw - 540px)
  }

  @keyframes collapse-width {
      0% {
          width: calc(100vw - 540px)
      }

      to {
          width: 0
      }
  }
}

@media screen and (max-width: 1199px) {
  .tekrevol-home-discovery .accordion.width .card .card-header {
      min-height:650px
  }

  .tekrevol-home-discovery .card-body {
      padding: 130px 15px 15px
  }

  .tekrevol-home-discovery .card-body .arrow {
      position: absolute;
      right: 10px;
      top: 50%
  }

  .tekrevol-home-discovery .card-body .arrow svg {
      height: 20px;
      width: auto
  }

  .tekrevol-home-discovery .card-body .discovery-bg svg {
      height: 270px;
      width: auto
  }

  .tekrevol-home-discovery .card-body .main-title {
      font-size: 26px;
      line-height: 1.3;
      margin-bottom: 60px
  }

  .tekrevol-home-discovery .card-body .content-wrap .title {
      font-size: 19px;
      line-height: 1.3
  }
}

@media screen and (max-width: 991px) {
  .tekrevol-home-discovery .accordion.width {
      border-bottom:4px solid #001b28;
      border-top: 4px solid #001b28;
      flex-direction: column
  }

  .tekrevol-home-discovery .accordion.width .card {
      flex-direction: column
  }

  .tekrevol-home-discovery .accordion.width .card .card-header {
      border-bottom: 4px solid #001b28;
      border-top: 4px solid #001b28;
      justify-content: start;
      letter-spacing: 2px;
      min-height: 60px;
      padding-left: 30px;
      text-align: center;
      text-align: left;
      transform: none;
      width: 100%;
      writing-mode: horizontal-tb
  }

  .tekrevol-home-discovery .accordion.width .card .card-header:before {
      bottom: -20px;
      left: 0;
      position: unset;
      right: 0;
      top: auto;
      transform: translateX(-50%) rotate(0deg)
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon {
      right: 20px;
      top: 8px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header.active .svg-arrow-icon {
      transform: none
  }

  .tekrevol-home-discovery .accordion.width .card:nth-child(odd) .card-header.active {
      background-color: #314252
  }

  .tekrevol-home-discovery .accordion.width .card-body {
      padding: 30px 15px;
      width: 100%
  }

  .tekrevol-home-discovery .accordion.width .card-body .arrow {
      display: none
  }

  .tekrevol-home-discovery .accordion.width .card-body .arrow svg {
      height: 20px;
      width: auto
  }

  .tekrevol-home-discovery .accordion.width .card-body .discovery-bg {
      display: none
  }

  .tekrevol-home-discovery .accordion.width .card-body .main-title {
      font-size: 22px;
      letter-spacing: 0;
      line-height: 1.3;
      margin-bottom: 30px;
      max-width: 100%
  }

  .tekrevol-home-discovery .accordion.width .card-body .content-wrap {
      max-width: 100%
  }

  .tekrevol-home-discovery .accordion.width .card-body .content-wrap .title {
      font-size: 18px
  }

  .tekrevol-home-discovery .collapse {
      max-height: 0
  }

  .tekrevol-home-discovery .collapse,.tekrevol-home-discovery .collapse.show {
      transition: max-height var(--duration) linear,width var(--duration) linear;
      width: 100%
  }

  .tekrevol-home-discovery .collapse.show {
      max-height: 1000px
  }

  .tekrevol-home-discovery .collapse:not(.show) {
      display: none!important;
      width: 100%
  }

  .tekrevol-home-discovery .collapse.collapsing {
      transition: max-height var(--duration) linear,width var(--duration) linear
  }
}

@media screen and (max-width: 767px) {
  .tekrevol-home-discovery .accordion.width .card .card-header {
      letter-spacing:0;
      padding-left: 20px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header:before {
      font-size: 16px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon {
      right: 20px;
      top: 13px
  }

  .tekrevol-home-discovery .accordion.width .card .card-header .svg-arrow-icon svg {
      height: 25px;
      width: auto
  }

  .tekrevol-home-discovery .accordion.width .card .card-header.active .svg-arrow-icon {
      transform: none
  }

  .tekrevol-home-discovery .accordion.width .card-body .arrow {
      display: none
  }

  .tekrevol-home-discovery .accordion.width .card-body .arrow svg {
      height: 20px;
      width: auto
  }
}
</style>